import os
import uuid
import json
from datetime import datetime
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, PlainTextResponse
from pydantic import BaseModel, validator

from app.generator import generator

app = FastAPI(title="SKV Network", description="Shared Knowledge Vault", version="1.8")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

entries_db = {}
delete_tokens = {}

class SKVEntry(BaseModel):
    skv_version: str = "1.0"
    user_fields: dict
    submission_url: Optional[str] = None
    attribution: Optional[dict] = None
    
    @validator('skv_version')
    def validate_version(cls, v):
        if v not in ["1.0"]: raise ValueError(f"Unsupported: {v}")
        return v

class EntryResponse(BaseModel):
    id: str
    public_url: str
    delete_token: str

@app.get("/", response_class=HTMLResponse)
async def home():
    return HTMLResponse(content="""<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>SKV v1.8</title><style>body{font-family:system-ui,sans-serif;max-width:900px;margin:0 auto;padding:20px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh}.container{background:white;padding:40px;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,0.2)}h1{color:#667eea}.feature{background:#f8f9fa;padding:20px;margin:15px 0;border-radius:8px;border-left:4px solid #667eea}code{background:#e9ecef;padding:2px 6px;border-radius:4px;font-family:monospace}.btn{display:inline-block;background:#667eea;color:white;padding:12px 24px;text-decoration:none;border-radius:8px;margin:10px 5px;font-weight:600}.btn:hover{background:#5568d3}.highlight{background:#e7f3ff;padding:15px;border-radius:8px;border-left:4px solid #007bff;margin-bottom:15px}</style></head><body><div class="container"><h1>📦 SKV Network v1.8</h1><p><strong>Shared Knowledge Vault</strong> — анкета сама знает, куда идти.</p><div class="highlight"><strong>✨ Новое:</strong> Теперь JSON содержит <code>submission_url</code> (куда кидать) и <code>attribution</code> (анонимно или нет).</div><div class="feature"><h3>🎯 Как это работает для ИИ</h3><ol><li>Ты говоришь ИИ: "Сохрани в SKV"</li><li>ИИ спрашивает: "Анонимно или нет?"</li><li>ИИ генерирует JSON со ссылкой внутри</li><li>Ты просто вставляешь этот JSON на <a href="/upload">эту страницу</a></li></ol></div><div style="margin-top:30px"><a href="/upload" class="btn">📤 Загрузить</a><a href="/template" class="btn">📋 Шаблон (с ссылкой)</a><a href="/api/v1/info" class="btn">🔧 API</a></div></div></body></html>""")

@app.get("/template", response_class=HTMLResponse)
async def template():
    tpl = {
        "skv_version": "1.0",
        "submission_url": "http://localhost:8000/api/v1/entries",
        "attribution": {"mode": "pseudonym", "value": "@YourName"},
        "user_fields": {
            "type": "generated_project",
            "project_name": "MyProject",
            "files": {"README.md": "# Project"},
            "insights": {"summary": "...", "tags": [], "domain": []}
        }
    }
    return HTMLResponse(content=f"""<!DOCTYPE html><html><head><meta charset="UTF-8"><title>SKV Template v1.8</title><style>body{{font-family:system-ui;max-width:900px;margin:0 auto;padding:20px;background:#f5f5f5}}.container{{background:white;padding:40px;border-radius:16px}}pre{{background:#2d2d2d;color:#f8f8f2;padding:20px;border-radius:8px;overflow-x:auto}}.btn{{background:#28a745;color:white;padding:10px 20px;border:none;border-radius:8px;cursor:pointer;font-size:16px;margin:10px 5px}}.note{{background:#fff3cd;padding:15px;border-radius:8px;border-left:4px solid #ffc107;margin-bottom:20px}}</style></head><body><div class="container"><h1>📋 Шаблон v1.8</h1><div class="note"><strong>👀 Смотри:</strong> В JSON ниже уже есть ссылка <code>submission_url</code> и настройки <code>attribution</code>. ИИ сгенерирует такой же, просто подставит свои данные.</div><pre id="tpl">{json.dumps(tpl, indent=2, ensure_ascii=False)}</pre><button class="btn" onclick="navigator.clipboard.writeText(document.getElementById('tpl').textContent)">📋 Копировать JSON</button><a href="/upload" class="btn" style="background:#007bff;text-decoration:none">📤 Перейти к загрузке</a></div></body></html>""")

@app.get("/guide", response_class=HTMLResponse)
async def guide():
    return HTMLResponse(content="""<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><title>SKV Guide</title><style>body{font-family:system-ui;max-width:900px;margin:0 auto;padding:20px;background:#f5f5f5}.container{background:white;padding:40px;border-radius:16px}h1{color:#667eea}h2{border-bottom:2px solid #667eea;padding-bottom:10px}pre{background:#2d2d2d;color:#f8f8f2;padding:15px;border-radius:8px;overflow-x:auto}code{background:#e9ecef;padding:2px 6px;border-radius:4px;font-family:monospace}.step{background:#e7f3ff;padding:15px;margin:10px 0;border-radius:8px;border-left:4px solid #007bff}</style></head><body><div class="container"><h1>📖 Инструкция v1.8</h1><h2>🤖 Сценарий "Сохранить в SKV"</h2><div class="step"><strong>1. Пользователь:</strong> "Сохрани проект в SKV"<br><strong>2. ИИ:</strong> "Анонимно или от имени (@ник)?"<br><strong>3. Пользователь:</strong> "Анонимно"<br><strong>4. ИИ:</strong> Генерирует JSON с <code>"attribution": {"mode": "anonymous"}</code> и ссылкой.<br><strong>5. Пользователь:</strong> Вставляет JSON на страницу <a href="/upload">/upload</a>.</div><h2>📋 Структура JSON</h2><pre>{
  "skv_version": "1.0",
  "submission_url": "http://localhost:8000/api/v1/entries",
  "attribution": {"mode": "anonymous"},
  "user_fields": { ... }
}</pre></div></body></html>""")

@app.get("/upload", response_class=HTMLResponse)
async def upload():
    return HTMLResponse(content="""<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>SKV Upload</title><style>body{font-family:system-ui;background:#f0f2f5;margin:0;padding:20px}.container{max-width:800px;margin:0 auto;background:white;padding:30px;border-radius:12px}textarea{width:100%;height:300px;padding:10px;border:1px solid #ccc;border-radius:8px;font-family:monospace;box-sizing:border-box}button{padding:12px 24px;border:none;border-radius:8px;cursor:pointer;font-size:16px;font-weight:bold;background:#007bff;color:white;margin-top:10px}.result{margin-top:20px;padding:15px;background:#e9ecef;border-radius:8px;display:none}.show{display:block!important}code{background:#dcdcdc;padding:2px 5px;border-radius:4px}.info{background:#e7f3ff;padding:10px;border-radius:6px;margin-bottom:15px;font-size:14px}</style></head><body><div class="container"><h1>📦 SKV Drop</h1><div class="info"><strong>💡 Совет:</strong> Убедись, что в JSON есть поля <code>submission_url</code> и <code>attribution</code> для порядка.</div><textarea id="jsonInput" placeholder='{"skv_version": "1.0", ...}'></textarea><button id="sendBtn" onclick="send()">🚀 Отправить</button><div class="result" id="result"><p><strong>ID:</strong> <code id="eid"></code></p><button onclick="location.href='/api/v1/entries/'+currentId+'/download'">📥 Скачать проект (ZIP)</button><button onclick="location.href='/api/v1/entries/'+currentId+'/export'">📄 Экспорт (TXT)</button></div></div><script>let currentId=null;async function send(){const btn=document.getElementById('sendBtn');const input=document.getElementById('jsonInput');const res=document.getElementById('result');btn.disabled=true;btn.textContent='⏳...';try{const r=await fetch('/api/v1/entries',{method:'POST',body:input.value,headers:{'Content-Type':'application/json'}});const d=await r.json();if(r.ok){currentId=d.id;document.getElementById('eid').textContent=d.id;res.classList.add('show')}else{alert('Error: '+JSON.stringify(d))}}catch(e){alert('Error: '+e)}btn.disabled=false;btn.textContent='🚀 Отправить'}</script></body></html>""")

@app.post("/api/v1/entries", response_model=EntryResponse, status_code=201)
async def create_entry(entry: SKVEntry):
    entry_id = str(uuid.uuid4())[:12]
    delete_token = f"skv_del_{uuid.uuid4().hex[:24]}"
    
    # Сохраняем метаданные отправки
    entry_data = {
        "id": entry_id,
        "created_at": datetime.utcnow().isoformat(),
        "skv_version": entry.skv_version,
        "user_fields": entry.user_fields,
        "views": 0,
        "meta": {
            "submission_url": entry.submission_url,
            "attribution": entry.attribution
        }
    }
    
    entries_db[entry_id] = entry_data
    delete_tokens[delete_token] = entry_id
    return EntryResponse(id=entry_id, public_url=f"https://skv.network/entry/{entry_id}", delete_token=delete_token)

@app.get("/api/v1/entries/{entry_id}")
async def get_entry(entry_id: str):
    if entry_id not in entries_db: raise HTTPException(404, "Not found")
    return entries_db[entry_id]

@app.delete("/api/v1/entries/{entry_id}")
async def delete_entry(entry_id: str, delete_token: str):
    if delete_token not in delete_tokens or delete_tokens[delete_token]!=entry_id: raise HTTPException(401, "Invalid")
    del entries_db[entry_id]; del delete_tokens[delete_token]
    return {"status":"deleted"}

@app.get("/api/v1/entries/{entry_id}/download")
async def download_zip(entry_id: str):
    if entry_id not in entries_db: raise HTTPException(404, "Not found")
    try:
        entry = entries_db[entry_id]
        # Передаем полные данные, включая мета, чтобы генератор создал meta.json
        path = generator.generate_zip(entry)
        name = entry.get('user_fields', {}).get('project_name', entry_id)
        return FileResponse(path=path, filename=f"{name}.zip", media_type='application/zip')
    except Exception as e: raise HTTPException(500, str(e))

@app.get("/api/v1/entries/{entry_id}/export")
async def export_txt(entry_id: str):
    if entry_id not in entries_db: raise HTTPException(404, "Not found")
    try:
        content = generator.generate_txt_export(entries_db[entry_id].get('user_fields', {}))
        name = entries_db[entry_id].get('user_fields', {}).get('project_name', entry_id)
        return PlainTextResponse(content=content, headers={"Content-Disposition": f'attachment; filename="{name}.txt"'})
    except Exception as e: raise HTTPException(500, str(e))

@app.get("/api/v1/info")
async def api_info():
    return {"service":"SKV Network","version":"1.8","description":"Shared Knowledge Vault - Submission Ready","endpoints":{"GET /":"Home","GET /upload":"Upload","GET /template":"Template with URL","POST /api/v1/entries":"Create"},"note":"JSON templates now include submission_url and attribution."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)