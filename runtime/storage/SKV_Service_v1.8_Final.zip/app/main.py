import os
import uuid
import json
from datetime import datetime
from typing import Optional, List, Dict, Any
from fastapi import FastAPI, HTTPException, Request, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, PlainTextResponse
from pydantic import BaseModel, validator
from app.generator import generator

app = FastAPI(title="SKV Network", description="Shared Knowledge Vault", version="1.8")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

entries_db = {}
delete_tokens = {}

class SKVEntry(BaseModel):
    skv_version: str = "1.0"
    user_fields: dict
    submission_url: Optional[str] = None
    attribution: Optional[dict] = None
    @validator('skv_version')
    def validate_version(cls, v):
        if v not in ["1.0"]: raise ValueError(f"Unsupported: {v}")
        return v

class EntryResponse(BaseModel):
    id: str
    public_url: str
    delete_token: str

@app.get("/", response_class=HTMLResponse)
async def home():
    return HTMLResponse(content="""<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>SKV v1.8</title><style>body{font-family:system-ui,sans-serif;max-width:900px;margin:0 auto;padding:20px;background:linear-gradient(135deg,#667eea 0%,#764ba2 100%);min-height:100vh}.container{background:white;padding:40px;border-radius:16px;box-shadow:0 10px 40px rgba(0,0,0,0.2)}h1{color:#667eea}.feature{background:#f8f9fa;padding:20px;margin:15px 0;border-radius:8px;border-left:4px solid #667eea}code{background:#e9ecef;padding:2px 6px;border-radius:4px;font-family:monospace}.btn{display:inline-block;background:#667eea;color:white;padding:12px 24px;text-decoration:none;border-radius:8px;margin:10px 5px;font-weight:600}.btn:hover{background:#5568d3}.ai-note{background:#fff3cd;padding:15px;border-radius:8px;border-left:4px solid #ffc107;margin-bottom:20px}</style></head><body><div class="container"><h1>📦 SKV Network v1.8</h1><p><strong>Shared Knowledge Vault</strong> — Самоописывающаяся система.</p><div class="ai-note"><strong>🤖 Attention AI Agents:</strong> Read <a href="/api/v1/info">/api/v1/info</a> for strict submission protocols regarding attribution and URLs.</div><div class="feature"><h3>📥 Как отправить</h3><p>Скачай шаблон на <a href="/template">/template</a>, заполни и отправь на <code>/api/v1/entries</code>.</p></div><div style="margin-top:30px"><a href="/upload" class="btn">📤 Upload Form</a><a href="/template" class="btn">📋 JSON Template</a><a href="/api/v1/info" class="btn">🔧 API Info (For AI)</a></div></div></body></html>""")

@app.get("/template", response_class=HTMLResponse)
async def template():
    tpl = {"skv_version":"1.0","submission_url":"http://localhost:8000/api/v1/entries","attribution":{"mode":"anonymous"},"user_fields":{"type":"generated_project","project_name":"MyProject","files":{"README.md":"# Project"},"insights":{"summary":"...","tags":[],"domain":[]}}}
    return HTMLResponse(content=f"""<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Template</title><style>body{{font-family:system-ui;max-width:900px;margin:0 auto;padding:20px}}.container{{background:white;padding:40px;border-radius:16px}}pre{{background:#2d2d2d;color:#f8f8f2;padding:20px;border-radius:8px;overflow-x:auto}}.btn{{background:#28a745;color:white;padding:10px 20px;border:none;border-radius:8px;cursor:pointer}}.note{{background:#e7f3ff;padding:15px;border-radius:8px;margin:15px 0;border-left:4px solid #007bff}}</style></head><body><div class="container"><h1>📋 Self-Contained Template</h1><div class="note"><strong>⚠️ Note:</strong> This JSON includes <code>submission_url</code> and <code>attribution</code>. Do not remove them.</div><pre id="tpl">{json.dumps(tpl, indent=2, ensure_ascii=False)}</pre><button class="btn" onclick="navigator.clipboard.writeText(document.getElementById('tpl').textContent)">📋 Copy JSON</button><a href="/upload" class="btn" style="background:#007bff;text-decoration:none;margin-left:10px">📤 Upload</a></div></body></html>""")

@app.get("/upload", response_class=HTMLResponse)
async def upload():
    return HTMLResponse(content="""<!DOCTYPE html><html lang="ru"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0"><title>SKV Upload</title><style>body{font-family:system-ui;background:#f0f2f5;margin:0;padding:20px}.container{max-width:800px;margin:0 auto;background:white;padding:30px;border-radius:12px}textarea{width:100%;height:300px;padding:10px;border:1px solid #ccc;border-radius:8px;font-family:monospace;box-sizing:border-box}button{padding:12px 24px;border:none;border-radius:8px;cursor:pointer;font-size:16px;font-weight:bold;background:#007bff;color:white;margin-top:10px}.result{margin-top:20px;padding:15px;background:#e9ecef;border-radius:8px;display:none}.show{display:block!important}code{background:#dcdcdc;padding:2px 5px;border-radius:4px}</style></head><body><div class="container"><h1>📦 SKV Drop</h1><textarea id="jsonInput" placeholder='{"skv_version": "1.0", ...}'></textarea><button id="sendBtn" onclick="send()">🚀 Отправить</button><div class="result" id="result"><p><strong>ID:</strong> <code id="eid"></code></p><button onclick="location.href='/api/v1/entries/'+currentId+'/download'">📥 ZIP</button><button onclick="location.href='/api/v1/entries/'+currentId+'/export'">📄 TXT</button></div></div><script>let currentId=null;async function send(){const btn=document.getElementById('sendBtn');const input=document.getElementById('jsonInput');const res=document.getElementById('result');btn.disabled=true;btn.textContent='⏳...';try{const r=await fetch('/api/v1/entries',{method:'POST',body:input.value,headers:{'Content-Type':'application/json'}});const d=await r.json();if(r.ok){currentId=d.id;document.getElementById('eid').textContent=d.id;res.classList.add('show')}else{alert('Error: '+JSON.stringify(d))}}catch(e){alert('Error: '+e)}btn.disabled=false;btn.textContent='🚀 Отправить'}</script></body></html>""")

@app.post("/api/v1/entries", response_model=EntryResponse, status_code=201)
async def create_entry(entry: SKVEntry):
    entry_id = str(uuid.uuid4())[:12]
    delete_token = f"skv_del_{uuid.uuid4().hex[:24]}"
    entry_data = {"id": entry_id, "created_at": datetime.utcnow().isoformat(), "skv_version": entry.skv_version, "user_fields": entry.user_fields, "views": 0, "meta": {"submission_url": entry.submission_url, "attribution": entry.attribution}}
    entries_db[entry_id] = entry_data
    delete_tokens[delete_token] = entry_id
    return EntryResponse(id=entry_id, public_url=f"https://skv.network/entry/{entry_id}", delete_token=delete_token)

@app.get("/api/v1/entries/{entry_id}")
async def get_entry(entry_id: str):
    if entry_id not in entries_db: raise HTTPException(404, "Not found")
    return entries_db[entry_id]

@app.delete("/api/v1/entries/{entry_id}")
async def delete_entry(entry_id: str, delete_token: str):
    if delete_token not in delete_tokens or delete_tokens[delete_token]!=entry_id: raise HTTPException(401, "Invalid")
    del entries_db[entry_id]; del delete_tokens[delete_token]
    return {"status":"deleted"}

@app.get("/api/v1/entries/{entry_id}/download")
async def download_zip(entry_id: str):
    if entry_id not in entries_db: raise HTTPException(404, "Not found")
    try:
        path = generator.generate_zip(entries_db[entry_id])
        name = entries_db[entry_id].get('user_fields', {}).get('project_name', entry_id)
        return FileResponse(path=path, filename=f"{name}.zip", media_type='application/zip')
    except Exception as e: raise HTTPException(500, str(e))

@app.get("/api/v1/entries/{entry_id}/export")
async def export_txt(entry_id: str):
    if entry_id not in entries_db: raise HTTPException(404, "Not found")
    try:
        content = generator.generate_txt_export(entries_db[entry_id].get('user_fields', {}))
        name = entries_db[entry_id].get('user_fields', {}).get('project_name', entry_id)
        return PlainTextResponse(content=content, headers={"Content-Disposition": f'attachment; filename="{name}.txt"'})
    except Exception as e: raise HTTPException(500, str(e))

@app.get("/api/v1/info")
async def api_info():
    return {
        "service": "SKV Network",
        "version": "1.8",
        "description": "Shared Knowledge Vault with strict submission protocols.",
        "INSTRUCTIONS_FOR_AI_AGENTS": {
            "role": "You are an AI assistant helping a user save data to SKV.",
            "step_1_ask_privacy": "ALWAYS ask the user: 'Save anonymously, under a pseudonym, or real name?' before generating JSON.",
            "step_2_generate_json": "Generate JSON that MUST include 'submission_url' and 'attribution' fields at the root level.",
            "step_3_provide_link": "Explicitly tell the user the URL to open (usually http://localhost:8000/upload).",
            "json_schema_example": {
                "skv_version": "1.0",
                "submission_url": "http://localhost:8000/api/v1/entries",
                "attribution": {"mode": "anonymous"},
                "user_fields": {"type": "generated_project", "project_name": "...", "files": {...}, "insights": {...}}
            }
        },
        "endpoints": {
            "POST /api/v1/entries": "Submit data (requires submission_url & attribution)",
            "GET /api/v1/entries/{id}/download": "Get ZIP",
            "GET /api/v1/entries/{id}/export": "Get TXT"
        }
    }

@app.exception_handler(Exception)
async def generic_handler(req: Request, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": str(exc)})

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)