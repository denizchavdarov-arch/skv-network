def get_date():
    return '2026-04-21'