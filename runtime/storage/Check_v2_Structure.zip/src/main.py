import os

def main():
    print('Hello from src/main.py!')

if __name__ == '__main__':
    main()