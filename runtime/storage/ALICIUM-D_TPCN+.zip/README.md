# ALICIUM-D TPCN+

Next-Generation Dynamic Ultra-High Temperature Ceramics

**Version:** 1.2  
**Author:** Chavdarov Deniz  
**Date:** April 20, 2026

## Abstract

ALICIUM-D TPCN+ (Variant B) is a modular platform of ultra-high temperature ceramic composites (UHTC) for reusable thermal protection systems.

**Key properties:**
- Density: 8.7–9.1 g/cm³
- Fracture toughness: 11–13 MPa·m¹/²
- Thermal stability: 2800–3200 °C (up to 3600 °C with REP)
- Self-healing: 45–75% recovery
- Thermal anisotropy: 9–12×

## Composition

Per 100g batch:
- HfB₂: 71.0g
- SiC: 15.0g
- ZrC: 2.0g
- CNT (MWNT): 4.0g
- TPCN: 5.0g
- B₄C: 1.0g