# Phase 2: REP Integration (Months 7–11, optional)

## Tasks

1. **REP precursor synthesis** (carboranes or B-N networks)

2. **Integration** into batch (8–10 wt%)

3. **Adjusted SPS** (max 1790–1800 °C)

4. **Validation:**
   - Flash DSC (endothermic response)
   - Thermal shock tests (+300–400 K buffer)
   - Extended cycling (up to 500 cycles)