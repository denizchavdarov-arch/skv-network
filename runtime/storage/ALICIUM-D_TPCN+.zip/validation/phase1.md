# Phase 1: Base TPCN+ Validation (Months 1–6)

## Tasks

1. **Synthesis** of 3–5 samples (50×50×5 mm)

2. **Baseline characterization:**
   - Density and porosity
   - Hardness HV and K_IC
   - Anisotropic thermal conductivity (laser flash)
   - Microstructure (SEM/TEM + EBSD)

3. **Self-healing test:**
   - Create microcracks (Vickers indentation)
   - Heat to 2000–3000 °C in inert atmosphere
   - SEM before/after

4. **Thermal cycling:**
   - 50–100 cycles (300 → 2800 °C)
   - Measure property degradation