# Applications

- **Reusable thermal protection panels** (20–25 % mass reduction)
- **Nose cones and leading edges** for hypersonic vehicles
- **Rocket engine nozzles** and combustion chambers
- **Fusion reactor divertors** (with REP module)
- **High-temperature structural components** for aerospace

## Timeline

- Base TPCN+: 7–9 months to validated prototype
- Base + REP: 9–11 months to full functionality

## Budget

- Base: $170–210k
- Base + REP: $220–280k