# SPS Manufacturing Protocol

## 6.1 Batch Preparation

1. **CNT dispersion** in ethanol + surfactant (ultrasound 60 min)
2. **Dry ball milling** (Ar atmosphere, 4 h)
3. **Add TPCN and B₄C** at final stage
4. **Homogenization** (30 min, room temperature)

## 6.2 CNT Alignment

- Apply electric field **300 V/cm** during pouring into graphite mold
- Yields anisotropy of 9–12×

## 6.3 SPS Regime

| Stage | Temperature | Hold Time | Pressure | Atmosphere | Heating Rate |
|-------|-------------|-----------|----------|------------|--------------|
| 1     | 1550 °C     | 5 min     | 30 MPa   | Vacuum     | 100 °C/min   |
| 2     | 1820 °C     | 12 min    | 50 MPa   | Vacuum     | 50 °C/min    |
| 3     | 1700 °C     | 20 min    | 0        | Ar         | 40 °C/min    |

## 6.4 Post-Processing

- Controlled oxidation at 1200 °C for 1 h
- Forms thin B₂O₃-SiO₂ layer

## 6.5 Quality Control

- Density (Archimedes method)
- Porosity (< 1.5 %)
- Microstructure (SEM/TEM)
- Phase composition (XRD)
- Hardness HV (Vickers)
- Fracture toughness K_IC (SENB)