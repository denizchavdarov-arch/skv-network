import os
import uuid
import json
from datetime import datetime
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, PlainTextResponse
from pydantic import BaseModel, validator

from app.generator import generator

app = FastAPI(
    title="SKV Network API",
    description="Shared Knowledge Vault",
    version="1.4"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

entries_db = {}
delete_tokens = {}

class SKVEntry(BaseModel):
    skv_version: str = "1.0"
    user_fields: dict
    
    @validator('skv_version')
    def validate_version(cls, v):
        if v not in ["1.0"]:
            raise ValueError(f"Unsupported SKV version: {v}")
        return v

class EntryResponse(BaseModel):
    id: str
    public_url: str
    delete_token: str

@app.get("/", response_class=HTMLResponse)
async def home_page(request: Request):
    return HTMLResponse(content="""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SKV Network - Shared Knowledge Vault</title>
        <style>
            body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
            .container { background: white; padding: 40px; border-radius: 16px; box-shadow: 0 10px 40px rgba(0,0,0,0.2); }
            h1 { color: #667eea; margin-top: 0; }
            .feature { background: #f8f9fa; padding: 20px; margin: 15px 0; border-radius: 8px; border-left: 4px solid #667eea; }
            .feature h3 { margin-top: 0; color: #333; }
            code { background: #e9ecef; padding: 2px 6px; border-radius: 4px; font-family: monospace; }
            .btn { display: inline-block; background: #667eea; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; margin: 10px 10px 10px 0; font-weight: 600; }
            .btn:hover { background: #5568d3; }
            pre { background: #2d2d2d; color: #f8f8f2; padding: 20px; border-radius: 8px; overflow-x: auto; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📦 SKV Network</h1>
            <p style="font-size: 1.2em; color: #666;"><strong>Shared Knowledge Vault</strong> — децентрализованное хранилище знаний</p>
            <div class="feature">
                <h3>🎯 Что это?</h3>
                <p>SKV — система для хранения структурированных знаний. Отправляешь JSON → получаешь ZIP и TXT.</p>
            </div>
            <div class="feature">
                <h3>🚀 Как использовать?</h3>
                <ol>
                    <li>Подготовь JSON с данными</li>
                    <li>Отправь через <a href="/upload">веб-форму</a></li>
                    <li>Скачай как <strong>ZIP</strong> (файлы) или <strong>TXT</strong> (документ)</li>
                </ol>
            </div>
            <div style="margin-top: 30px;">
                <a href="/upload" class="btn">📤 Загрузить</a>
                <a href="/guide" class="btn">📖 Инструкция</a>
                <a href="/template" class="btn">📋 Шаблон</a>
                <a href="/api/v1/info" class="btn">🔧 API</a>
            </div>
        </div>
    </body>
    </html>
    """)

@app.get("/guide", response_class=HTMLResponse)
async def guide_page(request: Request):
    return HTMLResponse(content="""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SKV Guide</title>
        <style>
            body { font-family: system-ui, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #f5f5f5; }
            .container { background: white; padding: 40px; border-radius: 16px; }
            h1 { color: #667eea; }
            h2 { color: #333; border-bottom: 2px solid #667eea; padding-bottom: 10px; margin-top: 30px; }
            pre { background: #2d2d2d; color: #f8f8f2; padding: 15px; border-radius: 8px; overflow-x: auto; }
            code { background: #e9ecef; padding: 2px 6px; border-radius: 4px; font-family: monospace; }
            .step { background: #e7f3ff; padding: 15px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #007bff; }
            a { color: #667eea; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📖 SKV Guide</h1>
            <h2>🎯 Для ИИ</h2>
            <div class="step">
                <strong>Если ты ИИ:</strong>
                <ol>
                    <li>Сформируй JSON по шаблону</li>
                    <li>Скажи: "Открой <a href='/upload' target='_blank'>/upload</a> и вставь JSON"</li>
                </ol>
            </div>
            <h2>📋 Шаблон</h2>
            <pre>{
  "skv_version": "1.0",
  "user_fields": {
    "type": "generated_project",
    "project_name": "MyProject",
    "files": {
      "README.md": "# Project",
      "main.py": "print('Hello')"
    },
    "insights": {
      "summary": "Description",
      "tags": ["tag1"],
      "domain": ["domain1"]
    }
  }
}</pre>
            <h2>🔗 Endpoints</h2>
            <ul>
                <li><code>GET /</code> — Главная</li>
                <li><code>GET /upload</code> — Загрузка</li>
                <li><code>GET /guide</code> — Инструкция</li>
                <li><code>GET /template</code> — Шаблон</li>
                <li><code>POST /api/v1/entries</code> — Создать</li>
                <li><code>GET /api/v1/entries/{id}/download</code> — ZIP</li>
                <li><code>GET /api/v1/entries/{id}/export</code> — TXT</li>
            </ul>
        </div>
    </body>
    </html>
    """)

@app.get("/template", response_class=HTMLResponse)
async def template_page(request: Request):
    template = {
        "skv_version": "1.0",
        "user_fields": {
            "type": "generated_project",
            "project_name": "MyProject",
            "files": {
                "README.md": "# My Project",
                "main.py": "def main():\n    print('Hello')"
            },
            "insights": {
                "summary": "Summary",
                "tags": ["python"],
                "domain": ["software"]
            }
        }
    }
    return HTMLResponse(content=f"""
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>SKV Template</title>
        <style>
            body {{ font-family: system-ui; max-width: 900px; margin: 0 auto; padding: 20px; background: #f5f5f5; }}
            .container {{ background: white; padding: 40px; border-radius: 16px; }}
            pre {{ background: #2d2d2d; color: #f8f8f2; padding: 20px; border-radius: 8px; }}
            .btn {{ background: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; margin: 10px 5px; }}
            a {{ color: #667eea; }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📋 SKV Template</h1>
            <pre id="tpl">{json.dumps(template, indent=2)}</pre>
            <button class="btn" onclick="navigator.clipboard.writeText(document.getElementById('tpl').textContent).then(()=>alert('Copied!'))">📋 Copy</button>
            <a href="/upload" class="btn" style="background:#007bff;text-decoration:none;display:inline-block">📤 Upload</a>
        </div>
    </body>
    </html>
    """)

@app.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request):
    return HTMLResponse(content="""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SKV Upload</title>
        <style>
            body { font-family: system-ui, sans-serif; background: #f0f2f5; margin: 0; padding: 20px; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
            h1 { margin-top: 0; }
            textarea { width: 100%; height: 300px; padding: 10px; border: 1px solid #ccc; border-radius: 8px; font-family: monospace; box-sizing: border-box; margin-bottom: 15px; }
            button { padding: 12px 24px; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: bold; margin-right: 10px; margin-top: 10px; }
            .btn-primary { background: #007bff; color: white; }
            .btn-success { background: #28a745; color: white; display: none; }
            .btn-info { background: #17a2b8; color: white; display: none; }
            .result-box { margin-top: 20px; padding: 15px; background: #e9ecef; border-radius: 8px; display: none; }
            .show { display: block !important; }
            code { background: #dcdcdc; padding: 2px 5px; border-radius: 4px; word-break: break-all; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📦 SKV Drop</h1>
            <p>Вставь JSON и нажми "Отправить".</p>
            <textarea id="jsonInput" placeholder='{"skv_version": "1.0", ...}'></textarea>
            <button class="btn-primary" id="sendBtn" onclick="sendData()">🚀 Отправить</button>
            <div class="result-box" id="resultBox">
                <p><strong>ID:</strong> <code id="entryId"></code></p>
                <button class="btn-success" id="btnZip" onclick="downloadZip()">📥 Скачать проект (ZIP)</button>
                <button class="btn-info" id="btnTxt" onclick="downloadTxt()">📄 Экспорт (TXT)</button>
            </div>
        </div>
        <script>
            let currentId = null;
            async function sendData() {
                const btn = document.getElementById('sendBtn');
                const input = document.getElementById('jsonInput');
                const resBox = document.getElementById('resultBox');
                btn.disabled = true;
                btn.textContent = '⏳ Отправка...';
                try {
                    const payload = JSON.parse(input.value);
                    const res = await fetch('/api/v1/entries', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(payload)
                    });
                    const data = await res.json();
                    if (res.ok) {
                        currentId = data.id;
                        document.getElementById('entryId').textContent = data.id;
                        resBox.classList.add('show');
                        document.getElementById('btnZip').style.display = 'inline-block';
                        document.getElementById('btnTxt').style.display = 'inline-block';
                    } else {
                        alert('Ошибка: ' + JSON.stringify(data));
                    }
                } catch (e) {
                    alert('Ошибка JSON: ' + e);
                }
                btn.disabled = false;
                btn.textContent = '🚀 Отправить';
            }
            function downloadZip() {
                if (currentId) window.location.href = `/api/v1/entries/${currentId}/download`;
            }
            function downloadTxt() {
                if (currentId) window.location.href = `/api/v1/entries/${currentId}/export`;
            }
        </script>
    </body>
    </html>
    """)

@app.post("/api/v1/entries", response_model=EntryResponse, status_code=201)
async def create_entry(entry: SKVEntry):
    entry_id = str(uuid.uuid4())[:12]
    delete_token = f"skv_del_{uuid.uuid4().hex[:24]}"
    entry_data = {
        "id": entry_id,
        "created_at": datetime.utcnow().isoformat(),
        "skv_version": entry.skv_version,
        "user_fields": entry.user_fields,
        "views": 0
    }
    entries_db[entry_id] = entry_data
    delete_tokens[delete_token] = entry_id
    return EntryResponse(
        id=entry_id,
        public_url=f"https://skv.network/entry/{entry_id}",
        delete_token=delete_token
    )

@app.get("/api/v1/entries/{entry_id}")
async def get_entry(entry_id: str):
    if entry_id not in entries_db:
        raise HTTPException(status_code=404, detail="Entry not found")
    return entries_db[entry_id]

@app.delete("/api/v1/entries/{entry_id}")
async def delete_entry(entry_id: str, delete_token: str):
    if delete_token not in delete_tokens:
        raise HTTPException(status_code=401, detail="Invalid delete token")
    stored_entry_id = delete_tokens[delete_token]
    if stored_entry_id != entry_id:
        raise HTTPException(status_code=403, detail="Token does not match entry")
    del entries_db[entry_id]
    del delete_tokens[delete_token]
    return {"status": "deleted", "id": entry_id}

@app.get("/api/v1/entries")
async def list_entries(limit: int = 50, offset: int = 0):
    entries = list(entries_db.values())
    total = len(entries)
    entries = entries[offset:offset + limit]
    return {"entries": entries, "total": total, "limit": limit, "offset": offset}

@app.get("/api/v1/entries/{entry_id}/download")
async def download_project(entry_id: str):
    if entry_id not in entries_db:
        raise HTTPException(status_code=404, detail="Entry not found")
    entry = entries_db[entry_id]
    try:
        zip_path = generator.generate_zip(entry.get('user_fields', {}))
        project_name = entry.get('user_fields', {}).get('project_name', entry_id)
        return FileResponse(
            path=zip_path,
            filename=f"{project_name}.zip",
            media_type='application/zip'
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/entries/{entry_id}/export")
async def export_document(entry_id: str):
    if entry_id not in entries_db:
        raise HTTPException(status_code=404, detail="Entry not found")
    entry = entries_db[entry_id]
    try:
        txt_content = generator.generate_txt_export(entry.get('user_fields', {}))
        project_name = entry.get('user_fields', {}).get('project_name', entry_id)
        return PlainTextResponse(
            content=txt_content,
            headers={"Content-Disposition": f'attachment; filename="{project_name}.txt"'},
            media_type='text/plain'
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/info")
async def api_info():
    return {
        "service": "SKV Network",
        "version": "1.4",
        "description": "Shared Knowledge Vault - самодокументируемая система",
        "features": [
            "Загрузка JSON → ZIP + TXT",
            "Автосоздание папок",
            "Инструкции для ИИ"
        ],
        "endpoints": {
            "GET /": "Главная",
            "GET /upload": "Загрузка",
            "GET /guide": "Инструкция",
            "GET /template": "Шаблон",
            "POST /api/v1/entries": "Создать",
            "GET /api/v1/entries/{id}/download": "ZIP",
            "GET /api/v1/entries/{id}/export": "TXT",
            "GET /api/v1/info": "API Info"
        },
        "for_ai": "Generate JSON per template, tell user to visit /upload"
    }

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal server error: {str(exc)}"}
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)