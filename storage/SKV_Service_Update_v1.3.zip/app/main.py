import os
import uuid
import json
from datetime import datetime
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse, PlainTextResponse
from pydantic import BaseModel, validator

from app.generator import generator

app = FastAPI(
    title="SKV Network API",
    description="Shared Knowledge Vault",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

entries_db = {}
delete_tokens = {}

class SKVEntry(BaseModel):
    skv_version: str = "1.0"
    user_fields: dict
    
    @validator('skv_version')
    def validate_version(cls, v):
        if v not in ["1.0"]:
            raise ValueError(f"Unsupported SKV version: {v}")
        return v

class EntryResponse(BaseModel):
    id: str
    public_url: str
    delete_token: str

@app.get("/health")
async def health_check():
    return {"status": "ok", "service": "skv-api", "timestamp": datetime.utcnow().isoformat()}

@app.get("/upload", response_class=HTMLResponse)
async def upload_page(request: Request):
    return HTMLResponse(content="""
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>SKV Upload</title>
        <style>
            body { font-family: system-ui, sans-serif; background: #f0f2f5; margin: 0; padding: 20px; }
            .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
            h1 { margin-top: 0; }
            textarea { width: 100%; height: 300px; padding: 10px; border: 1px solid #ccc; border-radius: 8px; font-family: monospace; box-sizing: border-box; margin-bottom: 15px; }
            button { padding: 12px 24px; border: none; border-radius: 8px; cursor: pointer; font-size: 16px; font-weight: bold; margin-right: 10px; margin-top: 10px; }
            .btn-primary { background: #007bff; color: white; }
            .btn-success { background: #28a745; color: white; display: none; }
            .btn-info { background: #17a2b8; color: white; display: none; }
            .result-box { margin-top: 20px; padding: 15px; background: #e9ecef; border-radius: 8px; display: none; }
            .show { display: block !important; }
            code { background: #dcdcdc; padding: 2px 5px; border-radius: 4px; word-break: break-all; }
        </style>
    </head>
    <body>
        <div class="container">
            <h1>📦 SKV Drop</h1>
            <p>Вставь JSON и нажми "Отправить".</p>
            <textarea id="jsonInput" placeholder='{"skv_version": "1.0", ...}'></textarea>
            
            <button class="btn-primary" id="sendBtn" onclick="sendData()">🚀 Отправить</button>
            
            <div class="result-box" id="resultBox">
                <p><strong>ID:</strong> <code id="entryId"></code></p>
                <button class="btn-success" id="btnZip" onclick="downloadZip()">📥 Скачать проект (ZIP)</button>
                <button class="btn-info" id="btnTxt" onclick="downloadTxt()">📄 Экспорт (TXT)</button>
            </div>
        </div>

        <script>
            let currentId = null;
            async function sendData() {
                const btn = document.getElementById('sendBtn');
                const input = document.getElementById('jsonInput');
                const resBox = document.getElementById('resultBox');
                btn.disabled = true;
                btn.textContent = '⏳ Отправка...';
                try {
                    const payload = JSON.parse(input.value);
                    const res = await fetch('/api/v1/entries', {
                        method: 'POST',
                        headers: {'Content-Type': 'application/json'},
                        body: JSON.stringify(payload)
                    });
                    const data = await res.json();
                    if (res.ok) {
                        currentId = data.id;
                        document.getElementById('entryId').textContent = data.id;
                        resBox.classList.add('show');
                        document.getElementById('btnZip').style.display = 'inline-block';
                        document.getElementById('btnTxt').style.display = 'inline-block';
                    } else {
                        alert('Ошибка: ' + JSON.stringify(data));
                    }
                } catch (e) {
                    alert('Ошибка JSON: ' + e);
                }
                btn.disabled = false;
                btn.textContent = '🚀 Отправить';
            }
            function downloadZip() {
                if (currentId) window.location.href = `/api/v1/entries/${currentId}/download`;
            }
            function downloadTxt() {
                if (currentId) window.location.href = `/api/v1/entries/${currentId}/export`;
            }
        </script>
    </body>
    </html>
    """)

@app.post("/api/v1/entries", response_model=EntryResponse, status_code=201)
async def create_entry(entry: SKVEntry):
    entry_id = str(uuid.uuid4())[:12]
    delete_token = f"skv_del_{uuid.uuid4().hex[:24]}"
    entry_data = {
        "id": entry_id,
        "created_at": datetime.utcnow().isoformat(),
        "skv_version": entry.skv_version,
        "user_fields": entry.user_fields,
        "views": 0
    }
    entries_db[entry_id] = entry_data
    delete_tokens[delete_token] = entry_id
    return EntryResponse(
        id=entry_id,
        public_url=f"https://skv.network/entry/{entry_id}",
        delete_token=delete_token
    )

@app.get("/api/v1/entries/{entry_id}")
async def get_entry(entry_id: str):
    if entry_id not in entries_db:
        raise HTTPException(status_code=404, detail="Entry not found")
    return entries_db[entry_id]

@app.delete("/api/v1/entries/{entry_id}")
async def delete_entry(entry_id: str, delete_token: str):
    if delete_token not in delete_tokens:
        raise HTTPException(status_code=401, detail="Invalid delete token")
    stored_entry_id = delete_tokens[delete_token]
    if stored_entry_id != entry_id:
        raise HTTPException(status_code=403, detail="Token does not match entry")
    del entries_db[entry_id]
    del delete_tokens[delete_token]
    return {"status": "deleted", "id": entry_id}

@app.get("/api/v1/entries")
async def list_entries(limit: int = 50, offset: int = 0):
    entries = list(entries_db.values())
    total = len(entries)
    entries = entries[offset:offset + limit]
    return {"entries": entries, "total": total, "limit": limit, "offset": offset}

@app.get("/api/v1/entries/{entry_id}/download")
async def download_project(entry_id: str):
    if entry_id not in entries_db:
        raise HTTPException(status_code=404, detail="Entry not found")
    entry = entries_db[entry_id]
    try:
        zip_path = generator.generate_zip(entry.get('user_fields', {}))
        project_name = entry.get('user_fields', {}).get('project_name', entry_id)
        return FileResponse(
            path=zip_path,
            filename=f"{project_name}.zip",
            media_type='application/zip'
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/v1/entries/{entry_id}/export")
async def export_document(entry_id: str):
    if entry_id not in entries_db:
        raise HTTPException(status_code=404, detail="Entry not found")
    entry = entries_db[entry_id]
    try:
        txt_content = generator.generate_txt_export(entry.get('user_fields', {}))
        project_name = entry.get('user_fields', {}).get('project_name', entry_id)
        return PlainTextResponse(
            content=txt_content,
            headers={"Content-Disposition": f'attachment; filename="{project_name}.txt"'},
            media_type='text/plain'
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/entry/{entry_id}", response_class=HTMLResponse)
async def public_entry(request: Request, entry_id: str):
    if entry_id not in entries_db:
        return HTMLResponse(content="<h1>Entry not found</h1>", status_code=404)
    entry = entries_db[entry_id]
    return HTMLResponse(content=f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>SKV Entry - {entry_id}</title>
        <style>
            body {{ font-family: system-ui, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
            pre {{ background: #f5f5f5; padding: 15px; border-radius: 8px; overflow-x: auto; }}
        </style>
    </head>
    <body>
        <h1>📄 SKV Entry: {entry_id}</h1>
        <p><strong>Created:</strong> {entry.get('created_at', 'N/A')}</p>
        <p><strong>Views:</strong> {entry.get('views', 0)}</p>
        <h2>Content:</h2>
        <pre>{json.dumps(entry.get('user_fields', {{}}), indent=2, ensure_ascii=False)}</pre>
    </body>
    </html>
    """)

@app.exception_handler(Exception)
async def generic_exception_handler(request: Request, exc: Exception):
    return JSONResponse(
        status_code=500,
        content={"detail": f"Internal server error: {str(exc)}"}
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)